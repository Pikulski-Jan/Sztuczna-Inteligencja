﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        private readonly Network n = new Network();
        private readonly string[] letter = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j"};

        private  static int imageSize = 5;
        static void Main(string[] args)
        {
            var p = new Program();
            p.n.maxIter = int.Parse(100.ToString());
            p.Test();
            p.Check();

            Console.ReadKey();
        }

        private void Test()
        {
            int length = letter.Length;
            n.Initialization(imageSize * imageSize, length);

            double[][] input = new double[length][];
            double[][] output = new double[length][];

            for (int i = 0; i < length; ++i)
            {
                output[i] = new double[length];

                for (int j = 0; j < length; ++j)
                {
                    output[i][j] = i == j ? 1.0 : 0.0;
                }

                n.layerO[i].value = letter[i];
            }

            input[0] = new double[25] { 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1 };//A
            input[1] = new double[25] { 1, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0 };//B
            input[2] = new double[25] { 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1 };//C
            input[3] = new double[25] { 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 };//D
            input[4] = new double[25] { 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1 };//E
            input[5] = new double[25] { 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0 };//F
            input[6] = new double[25] { 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0 };//G
            input[7] = new double[25] { 1, 0, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 1 };//H
            input[8] = new double[25] { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0 };//I
            input[9] = new double[25] { 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 };//J
            input[10] = new double[25] { 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0 };//a
            input[11] = new double[25] { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 };//b
            input[12] = new double[25] { 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0 };//c
            input[13] = new double[25] { 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0 };//d
            input[14] = new double[25] { 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0 };//e
            input[15] = new double[25] { 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0 };//f
            input[16] = new double[25] { 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0 };//g
            input[17] = new double[25] { 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0 };//h
            input[18] = new double[25] { 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0 };//i
            input[19] = new double[25] { 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 0, 0 };//j


            n.Train(input, output);

            
            for (int i = 0; i < n.currentIter; ++i)
            {
                Console.WriteLine("Error nr" + (i+1) + ": ");
                Console.WriteLine(n.errors[i].ToString("#0.000000"));
                Console.WriteLine("\n");
            }
        }

        private void Check()
        {
            double[] sample = new double[imageSize * imageSize];

            sample = new double[25] {1, 1, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0};

            n.Recognize(sample);

            Console.WriteLine("Result:");
            var results = new double[letter.Length];
            for (int i = 0; i < n.layerO.Length; ++i)
            {
                results[i] = n.layerO[i].Output;
                Console.WriteLine(n.layerO[i].value);
                Console.WriteLine(n.layerO[i].Output.ToString("#0.000000"));
            }

            int w = results.ToList().IndexOf(results.Max());
            if(w > letter.Length/2)
                Console.WriteLine("Discovered small letter: " + n.layerO[w].value);
            else
            {
                Console.WriteLine("Discovered big letter: " + n.layerO[w].value);
            }
        }


    }

    class Network
    {
        public struct InLayer
        {
            public double value;
            public double[] weights;
        }

        public struct OutLayer
        {
            public double InputAmount;
            public double Output;
            public double Error;
            public double Target;
            public string value;
        }

        public double learningRate = 0.1;

        public int ImageSize = 0;
        public int InputNum = 0;
        public int OutputNum = 0;

        public InLayer[] layerI = null;
        public OutLayer[] layerO = null;

        public double[] errors = null;

        public int currentIter = 0;
        public int maxIter = 100;

        public void Initialization(int iSize, int oSize)
        {
            InputNum = iSize;
            OutputNum = oSize;

            layerI = new Network.InLayer[iSize];
            layerO = new Network.OutLayer[oSize];


            Random random = new Random();

            for (int i = 0; i < InputNum; ++i){
                layerI[i].weights = new double[OutputNum];

                for (int j = 0; j < OutputNum; ++j){
                    layerI[i].weights[j] = random.Next(1, 3) / 100.0;
                }
            }
        }

        public bool Train(double[][] inputs, double[][] outputs){
            double currError = 0.0, maxError = 0.01;

            currentIter = 0;


            errors = new double[maxIter];

            do
            {
                currError = 0;

                for (int i = 0; i < inputs.Length; ++i){
                    CalculateOutput(inputs[i], layerO[i].value);
                    BackPropagation();

                    currError += GetError();
                }

                errors[currentIter] = currError;

                ++currentIter;
            }
            while (currError > maxError && currentIter < maxIter);


            if (currentIter <= maxIter){
                return true;
            }

            return false;
        }

        private void CalculateOutput(double[] exampl, string output){

            for (int i = 0; i < exampl.Length; i++)
            {
                layerI[i].value = exampl[i];
            }


            for (int i = 0; i < OutputNum; i++){
                double total = 0.0;

                for (int j = 0; j < InputNum; j++)
                {
                    total += layerI[j].value * layerI[j].weights[i];
                }

                layerO[i].InputAmount = total;
                layerO[i].Output = Activation(total);
                layerO[i].Target = layerO[i].value.CompareTo(output) == 0 ? 1.0 : 0.0;
                layerO[i].Error = (layerO[i].Target - layerO[i].Output) * (layerO[i].Output) * (1 - layerO[i].Output);
            }
        }

        public void Recognize(double[] input){
            for (int i = 0; i < InputNum; i++)
            {
                layerI[i].value = input[i];
            }

            for (int i = 0; i < OutputNum; i++)
            {
                double tmp = 0.0;

                for (int j = 0; j < InputNum; j++)
                {
                    tmp += layerI[j].value * layerI[j].weights[i];
                }

                layerO[i].InputAmount = tmp;
                layerO[i].Output = Activation(tmp);
            }
        }

        private void BackPropagation(){
            for (int j = 0; j < OutputNum; j++)
            {
                for (int i = 0; i < InputNum; i++)
                {
                    layerI[i].weights[j] += learningRate * (layerO[j].Error) * layerI[i].value;
                }
            }
        }

        private double GetError(){
            double total = 0.0;

            for (int j = 0; j < OutputNum; j++)
            {
                total += Math.Pow((layerO[j].Target - layerO[j].Output), 2.0) / 2.0;
            }

            return total;
        }

        private double Activation(double x){
            return (1.0 / (1.0 + Math.Exp(-x)));
        }

        
    }

}
