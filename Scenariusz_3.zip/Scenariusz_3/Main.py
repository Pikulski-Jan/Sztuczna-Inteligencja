from pybrain3 import *
from pybrain3.supervised.trainers import BackpropTrainer
from testinput import inputDataSet

network = FeedForwardNetwork()
letters = ["A", "B", "C", "D", "I", "F", "G", "H", "I", "U", "M", "E", "L", "O", "P", "R", "T", "W", "X", "Y"]

inLayer = LinearLayer(35)
hiddenLayer = SigmoidLayer(20)
outLayer = LinearLayer(20)
bias = BiasUnit()

network.addInputModule(inLayer)
network.addModule(bias)
network.addModule(hiddenLayer)
network.addOutputModule(outLayer)

bias_to_hidden = FullConnection(bias, hiddenLayer)
in_to_hidden = FullConnection(inLayer, hiddenLayer)
hidden_to_out = FullConnection(hiddenLayer, outLayer)

network.addConnection(bias_to_hidden)
network.addConnection(in_to_hidden)
network.addConnection(hidden_to_out)

network.sortModules()

inp = inputDataSet['input']
print("Number of training patterns: ", len(inputDataSet))

trainer = BackpropTrainer(network, dataset=inputDataSet, learningrate=0.1, verbose=False, momentum=0.01)

trainer.trainEpochs(5000)


print("\n\n")
for i in range(20):
    print("Dla litery",letters[i],"output wynosi:")
    temp = network.activate(inp[i])
    for j in range(20):
        print(temp[j])
    print("\n\n")





